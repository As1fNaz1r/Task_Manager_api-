from flask import request, jsonify
from flask_jwt_extended import create_access_token, jwt_required, get_jwt_identity
from werkzeug.security import generate_password_hash, check_password_hash
from app import app, db
from app.models import User, Task

# User Registration
@app.route('/api/register', methods=['POST'])
def register():
    data = request.get_json()
    hashed_password = generate_password_hash(data['password'], method='sha256')
    new_user = User(username=data['username'], password=hashed_password)
    db.session.add(new_user)
    db.session.commit()
    return jsonify({'message': 'User registered successfully'}), 201

# User Login
@app.route('/api/login', methods=['POST'])
def login():
    data = request.get_json()
    user = User.query.filter_by(username=data['username']).first()
    if user and check_password_hash(user.password, data['password']):
        access_token = create_access_token(identity={'id': user.id, 'username': user.username})
        return jsonify(access_token=access_token), 200
    return jsonify({'message': 'Invalid credentials'}), 401

# Create Task
@app.route('/api/tasks', methods=['POST'])
@jwt_required()
def create_task():
    data = request.get_json()
    user_id = get_jwt_identity()['id']
    new_task = Task(title=data['title'], description=data['description'], user_id=user_id, status=data.get('status', 'Todo'), priority=data.get('priority', 'Medium'), due_date=data.get('due_date'))
    db.session.add(new_task)
    db.session.commit()
    return jsonify({'message': 'Task created successfully'}), 201

# Get Tasks
@app.route('/api/tasks', methods=['GET'])
@jwt_required()
def get_tasks():
    user_id = get_jwt_identity()['id']
    tasks = Task.query.filter_by(user_id=user_id)

    status = request.args.get('status')
    priority = request.args.get('priority')
    due_date = request.args.get('due_date')
    search_query = request.args.get('search')

    if status:
        tasks = tasks.filter_by(status=status)
    if priority:
        tasks = tasks.filter_by(priority=priority)
    if due_date:
        tasks = tasks.filter(Task.due_date <= due_date)
    if search_query:
        tasks = tasks.filter((Task.title.contains(search_query)) | (Task.description.contains(search_query)))

    tasks = tasks.all()
    return jsonify(tasks=[task.to_dict() for task in tasks]), 200

# Update Task
@app.route('/api/tasks/<int:task_id>', methods=['PUT'])
@jwt_required()
def update_task(task_id):
    task = Task.query.get_or_404(task_id)
    data = request.get_json()

    task.title = data.get('title', task.title)
    task.description = data.get('description', task.description)
    task.status = data.get('status', task.status)
    task.priority = data.get('priority', task.priority)
    task.due_date = data.get('due_date', task.due_date)

    db.session.commit()
    return jsonify({'message': 'Task updated successfully'}), 200

# Delete Task
@app.route('/api/tasks/<int:task_id>', methods=['DELETE'])
@jwt_required()
def delete_task(task_id):
    task = Task.query.get_or_404(task_id)
    db.session.delete(task)
    db.session.commit()
    return jsonify({'message': 'Task deleted successfully'}), 200
